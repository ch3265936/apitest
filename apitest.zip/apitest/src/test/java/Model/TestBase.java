package Model;


public class TestBase {

    private String params;            //参数
    private String type;        //类型
    private String ass;
    private String apiname;
    private String key;
    private String value;
    public String getParams() {
        return params;
    }

    public String getType() {
        return type;
    }

    public String getAss() {
        return ass;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setAss(String ass) {
        this.ass = ass;
    }

    public String getApiname() {
        return apiname;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getKey() {
        return key;
    }
    public void setValue(String value) {
        this.value = value;
    }
    public String getValue() {
        return value;
    }
    @Override
    public String toString() {
        return "TestBase{" +
                "params='" + params + '\'' +
                ", type='" + type + '\'' +
                ", ass='" + ass + '\'' +
                ", apiname='" + apiname + '\'' +
                '}';
    }

    public void setApiname(String apiname) {
        this.apiname = apiname;
    }


}
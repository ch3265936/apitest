package utils;

import okhttp3.*;
import okio.BufferedSink;

import java.io.IOException;

public class HttpUtils {
    public static Response get(String url, String paramas) {
        //创建httpsclient
        Response result = null;
        OkHttpClient okHttpClient = new OkHttpClient();
        //去掉？
        Request request = new Request.Builder().url(url + paramas).get().build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            result = response;
            System.out.println(response.code());
            System.out.println(response.body());
            System.out.println(response.headers());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static Response post(String url, String paramas) {
        //创建httpsclient
        OkHttpClient okHttpClient = new OkHttpClient();
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencode");
        RequestBody requestBody = RequestBody.create(mediaType,paramas);
        //去掉？符号
        Request request = new Request.Builder().url(url).post(requestBody).build();
        Response  result =null;
        try {
            Response response = okHttpClient.newCall(request).execute();
            if (null != response.body()) {
                result = response;

            }
            System.out.println(response.code());
            System.out.println(response.body());
            System.out.println(response.headers());
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static Response call(String method ,String url,String paramas){
        if("get".equalsIgnoreCase(method)){
            System.out.println(get(url,paramas));
            return get(url,paramas);
        }else if ("post".equalsIgnoreCase(method)){
            return post(url,paramas);
        }
        return null;
    }

}

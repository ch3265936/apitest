package constants;

public class Constants {
    public static final String BASE_URL = "http://uat-livetest.bilibili.co";
    public static final String API_URL="https://api.live.bilibili.com";
    public static final String HOME_URL=BASE_URL+"/bangumi/play/";
    public static final String GET="get";

}

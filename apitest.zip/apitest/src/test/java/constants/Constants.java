package constants;

public class Constants {
    public static final String BASE_URL = "https://www.bilibili.com";
    public static final String HOME_URL=BASE_URL+"/bangumi/play/";
    public static final String GET="get";

}

package TestCase;

import Model.TestBase;
import constants.Constants;
import okhttp3.Response;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.ExcelHelper;
import utils.HttpUtils;
import java.io.File;
import java.util.List;

/**
 * 数据驱动api
 */
public class bilitest {

    @Test()
    public void init() {
        System.out.println("获取token");

    }

    @Test(dataProvider = "datas")
    public void test(TestBase tb) {
        TestBase testBase = tb;
        String url = Constants.HOME_URL;
        //接口方式
        String method = testBase.getType();
        Response result = HttpUtils.call(method, url, testBase.getParams());
        Assert.assertEquals(result.toString().contains(testBase.getAss()), true);
    }

    @DataProvider(name = "datas")
    public Object[] datas() {
        File file = new File("src/User_InterfaceCase.xlsx");
        List<TestBase> testBases = ExcelHelper.analysisExcel(file, TestBase.class);
        Object[] datas = new TestBase[testBases.size()];
        datas = testBases.toArray();
        return datas;
    }
}

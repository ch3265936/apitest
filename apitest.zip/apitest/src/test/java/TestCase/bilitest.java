package TestCase;

import Model.TestBase;
import com.alibaba.fastjson.JSONObject;
import constants.Constants;
import okhttp3.Response;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import utils.ExcelHelper;
import utils.HttpUtils;

import java.awt.*;
import java.io.File;
import java.util.List;

/**
 * 数据驱动api,模板式p0冒烟
 */
public class bilitest {

    @Test()
    public void init() {
        System.out.println("获取token");

    }

    @Test(dataProvider = "datas")
    public void test(TestBase tb) {
        //接口方式
        String method = tb.getType();
        Response result = HttpUtils.call(method, Constants.BASE_URL+tb.getApiname(), tb.getParams());
      try{
          String data=  result.body().string();
          Assert.assertEquals(data.contains(tb.getAss()), true);
      }catch (Exception e){

      }

    }

    @DataProvider(name = "datas")
    public Object[] datas() {
        File file = new File("src/User_InterfaceCase.xlsx");
        List<TestBase> testBases = ExcelHelper.analysisExcel(file, TestBase.class);
        Object[] datas = new TestBase[testBases.size()];
        datas = testBases.toArray();
        return datas;
    }
}
